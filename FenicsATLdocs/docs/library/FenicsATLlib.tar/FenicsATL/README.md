# FenicsATL
An ATLAS Fenics Board tests data analysis tools and functions library with some routine scripts.

# Documentation 
documentation available on https://github.com/wxssym/FenicsATLdoc and accessible on https://wxssym.github.io/FenicsATLdoc/.
